package rhes.ldap.reopsitry;


import java.util.List;

import rhes.ldap.model.User;

public interface UserRepositry {

	public String create(User user);
	public String deleteUser(String id);
	public List<User> retrieve();
	public List<User> SearchByName(String id);
}
