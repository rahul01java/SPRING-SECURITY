package rhes.ldap.reopsitry;

import org.springframework.data.ldap.repository.LdapRepository;

import rhes.ldap.model.User;

public interface MyRepositry extends LdapRepository<User>{

}
