package rhes.ldap.service;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

import java.util.List;

import javax.management.Query;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;

import org.apache.catalina.mapper.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.AbstractContextMapper;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.support.LdapNameBuilder;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.stereotype.Service;


import rhes.ldap.model.User;
import rhes.ldap.reopsitry.UserRepositry;

@Service
public class LdapService implements UserRepositry {

	final String base = "dc=memorynotfound,dc=com";
	
	@Autowired
	LdapTemplate template;
	
	@Override
	public String create(User user) {
		Name dn = buildDn(user.getId());
		template.bind(dn, null, buildAttributes(user));
		return "user created Sucessfully";
	}

	@Override
	public String deleteUser(String id) {
		Name name = buildDn(id);
		template.unbind(name);
		return id + "removed sucessfully";

	}

	public Name buildDn(String userId) {
		return LdapNameBuilder.newInstance(base).add("ou", "people").add("uid", userId).build();
	}

	private Attributes buildAttributes(User user) {

		BasicAttribute ocattr = new BasicAttribute("objectclass");
		ocattr.add("top");
		ocattr.add("person");
		Attributes attribute = new BasicAttributes();
		attribute.put(ocattr);
		attribute.put("uid", user.getId());
		attribute.put("cn", user.getName());
		attribute.put("password", user.getPassword());
		return attribute;
	}

	@Override
	public List<User> retrieve() {
		List<User> list=template.search(LdapQueryBuilder.query().where("objectclass").is("person"), new UserContextMapper());
		return list;
	}

	

	private static class UserContextMapper implements AttributesMapper<User> {
		@Override
		public User mapFromAttributes(Attributes attributes) throws NamingException {
			User user = new User();
			user.setName(null != attributes.get("cn") ? attributes.get("cn").get().toString() : null);
			user.setId(null != attributes.get("uid") ? attributes.get("uid").get().toString() : null);
			user.setPassword(
					null != attributes.get("password") ? attributes.get("password").get().toString() : null);
			return user;
		}
	}



	@Override
	public List<User> SearchByName(String name) {
		 LdapQuery q = query()
	                .where("objectclass").is("person")
	                .and("cn").whitespaceWildcardsLike(name);
	        return template.search(q, new UserContextMapper());
	}
}
