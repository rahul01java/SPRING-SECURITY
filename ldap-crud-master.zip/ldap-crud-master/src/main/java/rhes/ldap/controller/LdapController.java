package rhes.ldap.controller;

import java.util.List;

import javax.naming.Name;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import rhes.ldap.model.User;
import rhes.ldap.service.LdapService;

@RestController
@RequestMapping("/ldap/rest")
public class LdapController {
	@Autowired
	LdapService ldapService;

	@PostMapping("/add")
	public ResponseEntity<String> createNewUser(@RequestBody User user) {
		String name = ldapService.create(user);
		return new ResponseEntity<>(name, HttpStatus.OK);
	}
	@GetMapping("/name/{name}")
	public List<User> byName(@PathVariable String name){
		return  ldapService.SearchByName(name);
	}

	@GetMapping("/get-user")
	public List<User> getData() {
		return ldapService.retrieve();
	}
	@GetMapping("/remove/{uid}")
	public String removeUser(@PathVariable String uid) {
		return ldapService.deleteUser(uid);
	}

}
