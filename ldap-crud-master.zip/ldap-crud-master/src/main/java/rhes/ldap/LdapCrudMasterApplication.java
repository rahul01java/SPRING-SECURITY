package rhes.ldap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapCrudMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdapCrudMasterApplication.class, args);
	}

}
