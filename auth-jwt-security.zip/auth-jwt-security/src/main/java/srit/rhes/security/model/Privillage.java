package srit.rhes.security.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "my_privillage")
public class Privillage {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int id;
	protected String privillage_for;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPrivillage_for() {
		return privillage_for;
	}
	public void setPrivillage_for(String privillage_for) {
		this.privillage_for = privillage_for;
	}
	@Override
	public String toString() {
		return "Privillage [id=" + id + ", privillage_for=" + privillage_for + "]";
	}
	
}
