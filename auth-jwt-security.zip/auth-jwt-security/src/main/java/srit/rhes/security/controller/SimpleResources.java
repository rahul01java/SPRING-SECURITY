package srit.rhes.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import srit.rhes.security.filter.UserNotFoundException;
import srit.rhes.security.model.User;
import srit.rhes.security.repositery.UserRepositery;

@RestController
@RequestMapping("/rest")
public class SimpleResources {
	@Autowired
	UserRepositery repositry;

	@GetMapping("/process")
	public String process() {
		return "processing..";
	}
	@GetMapping("/ok")
	public String ok() {
		return "fine..";
	}

	@GetMapping("/all")
	public Iterable<User> getAll() {
		return repositry.findAll();
	}

	@GetMapping("/get")
	public String test() {
		return "hello";
	}
}
