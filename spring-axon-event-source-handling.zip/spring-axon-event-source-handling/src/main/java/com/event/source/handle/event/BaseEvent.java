package com.event.source.handle.event;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class BaseEvent<T> {
	@TargetAggregateIdentifier
	public final T id;

	public BaseEvent(T id) {
		this.id = id;
	}
	
}
