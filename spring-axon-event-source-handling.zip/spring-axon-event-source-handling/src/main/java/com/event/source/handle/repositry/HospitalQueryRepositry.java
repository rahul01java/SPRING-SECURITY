package com.event.source.handle.repositry;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.event.source.handle.query.entity.HospitalQuery;

public interface HospitalQueryRepositry extends CrudRepository<HospitalQuery, String> {
}
