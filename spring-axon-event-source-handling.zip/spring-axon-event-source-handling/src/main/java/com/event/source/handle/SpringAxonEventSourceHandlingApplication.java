package com.event.source.handle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAxonEventSourceHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAxonEventSourceHandlingApplication.class, args);
	}

}
