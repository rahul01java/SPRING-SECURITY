package com.event.source.handle.command;

public class MeetToDoctorCommand extends BaseCommand<String> {
	public final String doctor;
	public final String patientName;
	public final String specilist;

	public MeetToDoctorCommand(String id, String doctor, String patirntName, String specilist) {
		super(id);
		this.doctor = doctor;
		this.patientName = patirntName;
		this.specilist = specilist;
	}

}
