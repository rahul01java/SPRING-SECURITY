package com.event.source.handle.query;

import java.util.List;
import java.util.stream.Collectors;

import org.axonframework.eventsourcing.eventstore.EventStore;
import org.springframework.stereotype.Service;

import com.event.source.handle.query.entity.HospitalQuery;
import com.event.source.handle.repositry.HospitalQueryRepositry;

@Service
public class BookingQueryServiceImpl implements BookingQueryService {
	EventStore eventStore;
	HospitalQueryRepositry hospitalQueryRepositry;

	public BookingQueryServiceImpl(EventStore eventStore, HospitalQueryRepositry hospitalQueryRepositry) {
		this.eventStore = eventStore;
		this.hospitalQueryRepositry = hospitalQueryRepositry;
	}

	@Override
	public List<Object> listOfBookingEvent(String id) {
		return eventStore.readEvents(id).asStream().map(s -> s.getPayload()).collect(Collectors.toList());
	}

	@Override
	public HospitalQuery getEvent(String id) {
		return hospitalQueryRepositry.findById(id).get();
	}

}
