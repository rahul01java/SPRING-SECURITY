package com.event.source.handle.query;

import java.util.List;

import com.event.source.handle.query.entity.HospitalQuery;

public interface BookingQueryService {
	List<Object> listOfBookingEvent(String id);
	public HospitalQuery getEvent(String id);
}
