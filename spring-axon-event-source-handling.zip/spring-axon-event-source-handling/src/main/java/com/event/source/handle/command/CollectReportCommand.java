package com.event.source.handle.command;

public class CollectReportCommand extends BaseCommand<String> {
	public final String patientName;
	public final String collectReport;

	public CollectReportCommand(String id, String patientName, String collectReport) {
		super(id);
		this.patientName = patientName;
		this.collectReport = collectReport;
	}

}
