
package com.event.source.handle.entity.manager;

import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.event.source.handle.aggreate.HospitalManagement;
import com.event.source.handle.event.BaseEvent;
import com.event.source.handle.query.entity.HospitalQuery;
import com.event.source.handle.repositry.HospitalQueryRepositry;

@Component
public class EntityManager {

	@Autowired
	private HospitalQueryRepositry hospitalQueryRepositry;

	@Autowired
	private EventSourcingRepository<HospitalManagement> eventSourcingRepository;

	@EventSourcingHandler
	void on(BaseEvent event) {
		persistAccount(buildQueryAccount(getHospitalFromEvent(event)));
	}

	private HospitalManagement getHospitalFromEvent(BaseEvent event) {
		return eventSourcingRepository.load(event.id.toString()).getWrappedAggregate().getAggregateRoot();
	}

	private HospitalQuery findExistingOrCreateQueryAccount(String id) {
		return hospitalQueryRepositry.findById(id).isPresent() ? hospitalQueryRepositry.findById(id).get()
				: new HospitalQuery();
	}
	private HospitalQuery buildQueryAccount(HospitalManagement management) {
		HospitalQuery hospitalQuery = findExistingOrCreateQueryAccount(management.getId());
		hospitalQuery.setId(management.getId());
		hospitalQuery.setDoctor(management.getDoctor());
		hospitalQuery.setSpecilist(management.getSpecilist());
		hospitalQuery.setPatientName(management.getPatientName());
		hospitalQuery.setCollectReport(management.getCollectReport());
		hospitalQuery.setBookingStatus(management.getBookingStatus());
		return hospitalQuery;
	}

	

	private void persistAccount(HospitalQuery hospitalQueryEntity) {

		hospitalQueryRepositry.save(hospitalQueryEntity);
	}
}
