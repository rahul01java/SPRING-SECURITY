package com.event.source.handle.aggreate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import com.event.source.handle.command.BookAppointmentCommand;
import com.event.source.handle.command.CollectReportCommand;
import com.event.source.handle.command.MeetToDoctorCommand;
import com.event.source.handle.event.BookAppointmentEvent;
import com.event.source.handle.event.CollectReportEvent;
import com.event.source.handle.event.MeetToDoctorEvent;
import com.event.source.handle.event.StatusEvent;

@Aggregate
public class HospitalManagement {
	@AggregateIdentifier
	String id;
	String patientName;
	String doctor;
	String specilist;
	String collectReport;
	String bookingStatus;

	@CommandHandler
	public HospitalManagement(BookAppointmentCommand command) {
		AggregateLifecycle.apply(new BookAppointmentEvent(command.id, command.patientName, command.doctor));
	}

	@EventSourcingHandler
	public void on(BookAppointmentEvent appointmentEvent) {
		this.id = appointmentEvent.id;
		this.patientName = appointmentEvent.patientName;
		this.doctor = appointmentEvent.doctor;
		this.bookingStatus = String.valueOf(Status.Booked);
		AggregateLifecycle.apply(new com.event.source.handle.event.StatusEvent(this.id, Status.Booked));
	}

	@EventSourcingHandler
	public void on(StatusEvent event) {
		this.bookingStatus = String.valueOf(event.bookingStatus);
	}

	@CommandHandler
	public void on(MeetToDoctorCommand command) {
		AggregateLifecycle
				.apply(new MeetToDoctorEvent(command.id, command.doctor, command.patientName, command.specilist));
	}

	@EventSourcingHandler
	public void on(MeetToDoctorEvent toDoctorEvent) {
		this.id = toDoctorEvent.id;
		this.doctor = toDoctorEvent.doctor;
		this.patientName = toDoctorEvent.patientName;
		this.specilist = toDoctorEvent.specilist;
		AggregateLifecycle.apply(new StatusEvent(this.id, Status.MEETING));

	}

	@CommandHandler
	public void collectReport(CollectReportCommand reportCommand) {
		AggregateLifecycle.apply(
				new CollectReportEvent(reportCommand.id, reportCommand.patientName, reportCommand.collectReport));
	}

	/*
	 * @CommandHandler public HospitalManagement(CollectReportCommand reportCommand)
	 * { AggregateLifecycle.apply( new CollectReportEvent(reportCommand.id,
	 * reportCommand.patientName, reportCommand.collectReport)); }
	 */

	@EventSourcingHandler
	public void collectreportEvent(CollectReportEvent reportEvent) {
		this.id = reportEvent.id;
		this.patientName = reportEvent.patientName;
		this.collectReport = reportEvent.collectReport;
		AggregateLifecycle.apply(new StatusEvent(this.id, Status.REPORT));
	}

	public HospitalManagement() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getSpecilist() {
		return specilist;
	}

	public void setSpecilist(String specilist) {
		this.specilist = specilist;
	}

	public String getCollectReport() {
		return collectReport;
	}

	public void setCollectReport(String collectReport) {
		this.collectReport = collectReport;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	@Override
	public String toString() {
		return "HospitalManagement [id=" + id + ", patientName=" + patientName + ", doctor=" + doctor + ", specilist="
				+ specilist + ", collectReport=" + collectReport + ", bookingStatus=" + bookingStatus + "]";
	}

}
