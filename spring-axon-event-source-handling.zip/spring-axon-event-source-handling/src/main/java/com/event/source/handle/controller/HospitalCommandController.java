package com.event.source.handle.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.event.souece.handle.dto.AppointmentBookedDto;
import com.event.souece.handle.dto.CollectReportDto;
import com.event.souece.handle.dto.MeetToDoctorDto;
import com.event.source.handle.command.servoce.CommandService;

@RestController
@RequestMapping("/hospital")
public class HospitalCommandController {
	CommandService commandService;

	public HospitalCommandController(CommandService commandService) {
		this.commandService = commandService;
	}

	@PostMapping("book-appointment")
	public Future<String> bookAppointment(@RequestBody AppointmentBookedDto bookedDto) {
		System.out.println(bookedDto);
		return (CompletableFuture<String>)commandService.bookAppointment(bookedDto);
	}

	@PutMapping("/meet-doctor/{pNo}")
	public CompletableFuture<String> meetToDoctor(@PathVariable("pNo") String pNo,
			@RequestBody MeetToDoctorDto doctorDto) {
		return (CompletableFuture<String>) commandService.meetToDoctor(pNo,doctorDto);

	}

	@PutMapping("/collect-report/{pNo}")
	public CompletableFuture<String> collectReport(@PathVariable("pNo") String pNo,
			@RequestBody CollectReportDto reportDto) {
		return (CompletableFuture<String>) commandService.collectReport(pNo,reportDto);
	}
}
