
package com.event.source.handle.config;

import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.event.source.handle.aggreate.HospitalManagement;

@Configuration
public class EventQueryConfig {

	@Bean
	EventSourcingRepository<HospitalManagement> hospitalAggreateEventSourcing(EventStore event) {
		EventSourcingRepository<HospitalManagement> eventSourcingRepository = EventSourcingRepository
				.builder(HospitalManagement.class).eventStore(event).build();
		return eventSourcingRepository;

	}
}
