package com.event.source.handle.event;

import com.event.source.handle.aggreate.Status;

public class StatusEvent extends BaseEvent<String> {
	public final Status bookingStatus;

	public StatusEvent(String id, Status bookingStatus) {
		super(id);
		this.bookingStatus = bookingStatus;
	}

}
