package com.event.source.handle.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.event.source.handle.query.BookingQueryService;
import com.event.source.handle.query.entity.HospitalQuery;

@RestController
@RequestMapping("/hospital")
public class QueryController {
	private BookingQueryService queryService;

	public QueryController(BookingQueryService queryService) {
		super();
		this.queryService = queryService;
	}

	@GetMapping("/event/{id}")
	public List<Object> listEventsForAccount(@PathVariable(value = "id") String id) {
		return queryService.listOfBookingEvent(id);
	}

	@GetMapping("/one-event/{id}")
	public HospitalQuery getevent(@PathVariable("id") String id) {
		return queryService.getEvent(id);
	}

}
