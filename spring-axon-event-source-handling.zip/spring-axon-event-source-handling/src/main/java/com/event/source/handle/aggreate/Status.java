package com.event.source.handle.aggreate;

public enum Status {
   Booked,REPORT,MEETING
}
