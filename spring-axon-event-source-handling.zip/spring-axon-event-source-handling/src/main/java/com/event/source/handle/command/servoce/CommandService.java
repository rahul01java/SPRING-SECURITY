package com.event.source.handle.command.servoce;

import java.util.concurrent.Future;

import com.event.souece.handle.dto.AppointmentBookedDto;
import com.event.souece.handle.dto.CollectReportDto;
import com.event.souece.handle.dto.MeetToDoctorDto;

public interface CommandService {
public Future<String> bookAppointment(AppointmentBookedDto appointmentBookedDto);
public Future<String> meetToDoctor(String pNo,MeetToDoctorDto doctorDto);
public Future<String> collectReport(String pNo,CollectReportDto collectReportDto);
}
