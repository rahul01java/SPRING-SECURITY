package com.event.source.handle.event;

public class MeetToDoctorEvent extends BaseEvent<String> {
	public final String doctor;
	public final String patientName;
	public final String specilist;

	public MeetToDoctorEvent(String id, String doctor, String patientName, String specilist) {
		super(id);
		this.doctor = doctor;
		this.patientName = patientName;
		this.specilist = specilist;
	}

}
