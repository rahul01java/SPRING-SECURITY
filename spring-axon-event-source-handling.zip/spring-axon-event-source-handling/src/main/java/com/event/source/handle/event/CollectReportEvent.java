package com.event.source.handle.event;

public class CollectReportEvent extends BaseEvent<String> {
	public final String patientName;
	public final String collectReport;

	public CollectReportEvent(String id, String patientName, String collectReport) {
		super(id);
		this.patientName = patientName;
		this.collectReport = collectReport;
	}

}
