package com.event.source.handle.event;

public class BookAppointmentEvent extends BaseEvent<String> {
	public final String patientName;
	public final String doctor;

	public BookAppointmentEvent(String id, String patientName, String doctor) {
		super(id);
		this.patientName = patientName;
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "BookAppointmentEvent [patientName=" + patientName + ", doctor=" + doctor + "]";
	}

}
