package com.event.source.handle.command.servoce;

import java.util.UUID;
import java.util.concurrent.Future;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.stereotype.Service;

import com.event.souece.handle.dto.AppointmentBookedDto;
import com.event.souece.handle.dto.CollectReportDto;
import com.event.souece.handle.dto.MeetToDoctorDto;
import com.event.source.handle.command.BookAppointmentCommand;
import com.event.source.handle.command.CollectReportCommand;
import com.event.source.handle.command.MeetToDoctorCommand;
@Service
public class CommandServiceImpl implements CommandService {
	public CommandGateway commandGateway;

	public CommandServiceImpl(CommandGateway commandGateway) {
		this.commandGateway = commandGateway;
	}

	@Override
	public Future<String> bookAppointment(AppointmentBookedDto appointmentBookedDto) {
		System.out.println(appointmentBookedDto);
		return commandGateway.send(new BookAppointmentCommand(UUID.randomUUID().toString(),
				appointmentBookedDto.getPatientName(), appointmentBookedDto.getDoctor()));
	}

	
	@Override
	public Future<String> collectReport(String pNo, CollectReportDto collectReportDto) {
		// TODO Auto-generated method stub
		return commandGateway.send(
				new CollectReportCommand(pNo,collectReportDto.getPatientName(), collectReportDto.getCollectReport()));
	}

	@Override
	public Future<String> meetToDoctor(String pNo, MeetToDoctorDto doctorDto) {
		// TODO Auto-generated method stub
		return commandGateway.send(new MeetToDoctorCommand(pNo,doctorDto.getDoctor(), doctorDto.getPatientName(), doctorDto.getSpecilist()));
	}

}
