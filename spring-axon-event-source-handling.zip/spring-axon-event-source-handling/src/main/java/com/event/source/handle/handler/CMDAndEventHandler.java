/*
 * package com.event.source.handle.handler;
 * 
 * import org.axonframework.commandhandling.CommandHandler;
 * 
 * import org.axonframework.eventhandling.EventHandler; import
 * org.axonframework.eventsourcing.EventSourcingHandler; import
 * org.axonframework.modelling.command.AggregateLifecycle; import
 * org.axonframework.spring.stereotype.Aggregate; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.stereotype.Component; import
 * org.springframework.stereotype.Service;
 * 
 * import com.event.source.handle.aggreate.HospitalManagement; import
 * com.event.source.handle.aggreate.Status; import
 * com.event.source.handle.command.BookAppointmentCommand; import
 * com.event.source.handle.command.CollectReportCommand; import
 * com.event.source.handle.command.MeetToDoctorCommand; import
 * com.event.source.handle.event.BookAppointmentEvent; import
 * com.event.source.handle.event.CollectReportEvent; import
 * com.event.source.handle.event.MeetToDoctorEvent; import
 * com.event.source.handle.event.StatusEvent;
 * 
 * @Component public class CMDAndEventHandler {
 * 
 * public final HospitalManagement hospitalManagement;
 * 
 * @Autowired public CMDAndEventHandler(HospitalManagement hospitalManagement) {
 * this.hospitalManagement = hospitalManagement; }
 * 
 * @CommandHandler public void bookAppointmentCmd(BookAppointmentCommand
 * appointmentCommand) {
 * org.axonframework.modelling.command.AggregateLifecycle.apply(new
 * BookAppointmentEvent(appointmentCommand.id, appointmentCommand.patientName,
 * appointmentCommand.doctor)); }
 * 
 * @EventSourcingHandler public void bookAppointMentEvent(BookAppointmentEvent
 * appointmentEvent) { hospitalManagement.setId(appointmentEvent.id);
 * hospitalManagement.setPatientName(appointmentEvent.patientName);
 * hospitalManagement.setDoctor(appointmentEvent.doctor);
 * hospitalManagement.setBookingStatus(String.valueOf(Status.Booked));
 * AggregateLifecycle.apply(new StatusEvent(hospitalManagement.getId(),
 * Status.Booked)); }
 * 
 * @EventHandler public void bookingStatusEvent(StatusEvent event) {
 * hospitalManagement.setBookingStatus(String.valueOf(event)); }
 * 
 * @CommandHandler public void meetToDoctor(MeetToDoctorCommand doctorCommand) {
 * AggregateLifecycle.apply(new MeetToDoctorEvent(doctorCommand.id,
 * doctorCommand.doctor, doctorCommand.patientName, doctorCommand.specilist)); }
 * 
 * @EventSourcingHandler public void meetToDoctorvent(MeetToDoctorEvent
 * doctorEvent) { AggregateLifecycle.apply(new MeetToDoctorEvent(doctorEvent.id,
 * doctorEvent.doctor, doctorEvent.patientName, doctorEvent.specilist));
 * 
 * }
 * 
 * @CommandHandler public void colletctRepoetCommand(CollectReportCommand
 * collectReportCommand) { AggregateLifecycle.apply(new
 * CollectReportEvent(collectReportCommand.id, collectReportCommand.patientName,
 * collectReportCommand.collectReport)); }
 * 
 * @EventSourcingHandler public void collectReportEvent(CollectReportEvent
 * collectReportEvent) { AggregateLifecycle.apply(new
 * CollectReportEvent(collectReportEvent.id, collectReportEvent.patientName,
 * collectReportEvent.collectReport)); } }
 */