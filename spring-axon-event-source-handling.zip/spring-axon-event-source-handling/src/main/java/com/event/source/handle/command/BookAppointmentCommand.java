package com.event.source.handle.command;

public class BookAppointmentCommand extends BaseCommand<String> {
	public final String patientName;
	public final String doctor;

	public BookAppointmentCommand(String id, String patientName, String doctor) {
		super(id);
		this.patientName = patientName;
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "BookAppointmentCommand [patientName=" + patientName + ", doctor=" + doctor + "]";
	}

}
