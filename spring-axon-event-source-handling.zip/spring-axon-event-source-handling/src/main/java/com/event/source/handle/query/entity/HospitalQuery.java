package com.event.source.handle.query.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HospitalQuery {
	@Id
	String id;
	String patientName;
	String doctor;
	String specilist;
	String collectReport;
	String bookingStatus;

	public HospitalQuery() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getSpecilist() {
		return specilist;
	}

	public void setSpecilist(String specilist) {
		this.specilist = specilist;
	}

	public String getCollectReport() {
		return collectReport;
	}

	public void setCollectReport(String collectReport) {
		this.collectReport = collectReport;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	@Override
	public String toString() {
		return "HospitalQuery [id=" + id + ", patientName=" + patientName + ", doctor=" + doctor + ", specilist="
				+ specilist + ", collectReport=" + collectReport + ", bookingStatus=" + bookingStatus + "]";
	}

}
