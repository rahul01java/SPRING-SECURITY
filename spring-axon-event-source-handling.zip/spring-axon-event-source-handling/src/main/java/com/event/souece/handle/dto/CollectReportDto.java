package com.event.souece.handle.dto;

public class CollectReportDto {
	public String patientName;
	public String collectReport;

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getCollectReport() {
		return collectReport;
	}

	public void setCollectReport(String collectReport) {
		this.collectReport = collectReport;
	}

	@Override
	public String toString() {
		return "CollectReportDti [patientName=" + patientName + ", collectReport=" + collectReport + "]";
	}

}
