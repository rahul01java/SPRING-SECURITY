package com.event.souece.handle.dto;

public class AppointmentBookedDto {
	public String patientName;
	public String doctor;

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "AppointmentBookedDto [patientName=" + patientName + ", doctor=" + doctor + "]";
	}

}
