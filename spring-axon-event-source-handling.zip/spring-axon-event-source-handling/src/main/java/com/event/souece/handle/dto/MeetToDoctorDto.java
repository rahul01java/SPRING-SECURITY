package com.event.souece.handle.dto;

public class MeetToDoctorDto {
	public String doctor;
	public String patientName;
	public String specilist;

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getSpecilist() {
		return specilist;
	}

	public void setSpecilist(String specilist) {
		this.specilist = specilist;
	}

	@Override
	public String toString() {
		return "MeetToDoctorDto [doctor=" + doctor + ", patientName=" + patientName + ", specilist=" + specilist + "]";
	}

}
