package com.event.source.handle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAxonEventSourceHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
