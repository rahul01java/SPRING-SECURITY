package com.oauth.security.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oauth.security.model.AuthRequest;
import com.oauth.security.util.JwtUtil;

@RestController
@RequestMapping("/rest")
public class ApplicationController {
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtUtil jwtUtil;

	@GetMapping("/process")
	@PreAuthorize("hasAnyRole('ADMIN')")
	public String process() {
		return "processing..";
	}

	@GetMapping("/check")
	@PreAuthorize("hasAnyRole('CHECK')")
	public String checkup() {
		return "go for checkups...";
	}

	@GetMapping("/medical")
	@PreAuthorize("hasAnyRole('MEDICAL')")
	public String medical() {
		return "welcome to medicine..";
	}

	@GetMapping("/doctor")
	@PreAuthorize("hasAnyRole('ROLE_DOCTOR')")
	public String doctor() {
		return "welcome to doctor menu...";
	}

	@GetMapping("/lab")
	@PreAuthorize("hasAnyRole('ROLE_LAB')")
	public String lab() {
		return "welcome to lab ...";
	}

	@GetMapping("/ok")
	public String test() {
		return "okfine";
	}

	@PostMapping("/delete")
	@PreAuthorize("permitAll()")
	public String deleteSession(HttpServletRequest request) {
		request.getSession().invalidate();
		return "invalidate";
	}

	@PostMapping("/authenticate")
	public String generateToken(@RequestBody AuthRequest authRequest) throws Exception {
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword()));
		} catch (Exception ex) {
			throw new Exception("inavalid username/password");
		}
		return jwtUtil.generateToken(authRequest.getUserName());
	}

}
