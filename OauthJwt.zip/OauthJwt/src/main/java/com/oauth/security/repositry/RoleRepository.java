package com.oauth.security.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oauth.security.model.Role;


public interface RoleRepository extends JpaRepository<Role, Integer>{

}
