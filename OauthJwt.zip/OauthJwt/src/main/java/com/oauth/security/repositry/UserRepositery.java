package com.oauth.security.repositry;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.oauth.security.model.User;

@Repository
public interface UserRepositery extends JpaRepository<User,Integer>{
	
    User findByUserName(String userName);
	
  
}
