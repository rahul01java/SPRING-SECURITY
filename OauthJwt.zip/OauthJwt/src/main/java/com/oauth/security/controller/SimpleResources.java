package com.oauth.security.controller;

import java.security.Principal;

import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class SimpleResources {

	@GetMapping(path = "/hello", produces = MediaType.TEXT_PLAIN_VALUE)
	@PreAuthorize("hasAnyRole('ROLE_DOCTOR')")
	public String ping() {
		return "hello";
	}

	@GetMapping(path = "/welcome", produces = MediaType.TEXT_PLAIN_VALUE)
	@PreAuthorize("hasAnyRole('ROLE_ADMIN')")
	public String show() {
		return "welcome";
	}

	@GetMapping(path = "/principle", produces = MediaType.TEXT_PLAIN_VALUE)
	@PreAuthorize("hasAnyRole('ROLE_USER')")
	public String show(Principal principal) {
		String name = principal.getName();
		return name;
	}

}
