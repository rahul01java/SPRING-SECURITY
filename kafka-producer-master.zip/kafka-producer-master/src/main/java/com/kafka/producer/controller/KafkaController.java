package com.kafka.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.producer.model.Hospital;
@RestController
@RequestMapping("/message")
public class KafkaController {
	final String topic = "kafka_example";
	@Autowired
	KafkaTemplate<String, Hospital> kafkaTemplate;
  @PostMapping("/produce/{name}")
	public String post(@PathVariable("name") String name) {
		kafkaTemplate.send(topic, new Hospital(1, name, "banglore", "Karnatka", "india"));
		return "published Sucessfully....";
	}
}
